from fastapi.params import Form
from fastapi import FastAPI,Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import starlette.status as status 
from starlette.responses import RedirectResponse,Response
 
app = FastAPI()

app.mount("/static",StaticFiles(directory="static"),"static")

static = Jinja2Templates("static")

@app.get("/", response_class=HTMLResponse)
def index(request:Request):
    return static.TemplateResponse("login2.html",{"request":request})
     
@app.post("/",response_class=HTMLResponse)
def index_post(request:Request, email:str = Form(...), password:str=Form(...)):
    ### db.insert('user',{"email":eamil, "password":password})
    if(password != "12345"):
        return static.TemplateResponse("login2.html",{"request":request,"msg":"invalid login"})
    return RedirectResponse("/",status_code=status.HTTP_302_FOUND)
